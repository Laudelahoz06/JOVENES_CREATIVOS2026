# Notas de avance — Magical Books Café

> Última actualización: 2026-11-10
>
> ⚠️ **Regla del equipo:** NO hacer commit de los cambios realizados en esta máquina.

## Estado general
- **Rama:** `main`, sincronizada con `origin/main` — **últimos commits bajados:** `5babd6d` (inicio de sesión, crear cuenta y nav dinámico) y `9f157fc` (avance React). **Nada de nuestro trabajo se sube al Git (regla del equipo).**
- **Stack:** Node.js + Express 5 + Mongoose (backend) · React 19 + Vite (frontend) · JavaScript puro (sin TS)
- **Proveedor cloud:** **MongoDB Atlas en uso** (cluster `cluster0.ziemfyj`, DB `magical_books_cafe`), IP `0.0.0.0/0` (si tu IP pública cambia y no usas 0.0.0.0/0, el backend no conecta). Puerto del backend: **5000**
- **Servidores (2026-11-10):** backend `http://localhost:5000` · frontend `http://localhost:5173` (Vite). Si el backend "no responde", revisar con `Get-NetTCPConnection -LocalPort 5000 -State Listen` quién escucha y relanzar `node src/server.js`.
- **Documentación:**
  - `magical-books-cafe/docs/GUIA_DESARROLLO.md` + **`.docx`** (guía técnica, ampliada con las 15 funcionalidades)
  - `magical-books-cafe/docs/PRESENTACION_PROYECTO.md` + **`.docx`** (presentación y evidencias)
  - `magical-books-cafe/README.md` (arranque rápido, scripts, rutas)

## Qué está hecho
- **Backend completo (2026-11-10):** auth (register/login/profile/logout + `PATCH /auth/profile` con preferencias), CRUD productos admin, inventario con historial, **contacto** (`/api/contact` con bandeja admin), **pedidos** (`/api/orders` con revalidación de precios/stock), **alquileres** (`/api/rentals` con `fisico|digital|kindle|local_pc`), **IA** (`/api/ai/assistant` con motor local + OpenAI opcional), **usuarios admin** (`GET/PATCH /api/admin/users` con protección de auto-desactivación), seguridad (helmet, CORS, rate-limit, express-validator), manejo centralizado de errores
- **Modelos:** `User`, `Product`, `Rental` (enum format ampliado con `fisico`), `Order`, `ContactMessage`, `InventoryMovement`
- **Pruebas automáticas (36 OK, 0 fallidas):** `npm test` (17) y `npm run test:admin` (19) en `backend/`; scripts `smokeTest.js` y `adminSmokeTest.js`
- **Frontend completo:** Home, Catálogo (búsqueda con debounce, filtros, paginación, skeletons), **ficha de producto `/catalogo/:id`** (formatos, cantidad, carrito, formulario de alquiler), **/contacto** con validación en vivo, **/carrito** (CartContext + localStorage, checkout con confirmación), **/perfil** (datos, preferencias, historial de pedidos), **/mis-alquileres** (ticket y estado), **/admin** con 5 pestañas (Productos, Pedidos, Alquileres, Mensajes, Usuarios), **widget flotante de asistente IA**, Navbar con contador de carrito, `styles/features.css`
- **Auth verificado end-to-end** y lint del frontend en **0 problemas**; `npm run build` OK (CSS ~31 kB, JS ~328 kB); los 16 módulos nuevos se sirven sin error en Vite
- **Seed actualizado:** `scripts/seedProducts.js` ahora hace **upsert por SKU** y fija `stock` (cafés 50, postres 30, libros 4-5, servicio 100) — corrige los 409 "Stock insuficiente" del pedido inicial
- **Utilidades:** `npm run promote-admin <correo>` (promueve a admin), `npm run check` (sintaxis)

## Qué falta (prioridad sugerida)
1. **Imágenes reales de productos** (hoy todo usa `ProductoNoDisponible.png`)
2. **Proveedor de IA:** configurar `AI_API_KEY`/`AI_MODEL` en `backend/.env` para respuestas abiertas (el motor local ya funciona)
3. **Despliegue** (frontend estático + backend + Atlas)
4. **Pruebas de frontend** (Vitest + Testing Library)
5. Actualizar `DOCUMENTACION_PROYECTO.md` y `AGENTS.md` (rutas reales: `/iniciar-sesion`, `/registro`; `VITE_API_URL` debe llevar `/api`)

## Checklist de setup local
- [x] `npm install` en `magical-books-cafe/backend`
- [x] `npm install` en `magical-books-cafe/frontend`
- [x] Crear `magical-books-cafe/backend/.env` con tu URI de MongoDB Atlas (cuenta ya creada):
      `PORT=5000`, `NODE_ENV=development`, `MONGODB_URI=<mongodb+srv://...>/magical_books_cafe?retryWrites=true&w=majority`, `FRONTEND_URL=http://localhost:5173`, `JWT_SECRET=...`, `JWT_EXPIRES_IN=1h`
- [x] `npm run dev` en backend (puerto 5000) y `npm run dev` en frontend (puerto 5173)
- [x] Verificar `http://localhost:5000/api/health` → `success: true`
- [x] Verificar `http://localhost:5000/api/products` → 7 productos con stock

## Semilla de datos
```bash
# backend — crea/actualiza 7 productos (upsert por SKU, con stock de ejemplo)
npm run seed
```

## Comandos
```bash
# backend (requiere .env con MONGODB_URI de Atlas)
npm run dev             # nodemon src/server.js (puerto 5000)
npm start               # node src/server.js
npm run seed            # upsert de productos de ejemplo
npm run promote-admin <correo>   # promover usuario a admin
npm test                # 17 pruebas de humo
npm run test:admin      # 19 pruebas administrativas

# frontend
npm run dev             # vite (5173)
npm run build
npm run lint
```

## Tipos de datos (esquemas Mongoose)
- **User:** name/email/phone (`String`), password (`String`, select:false), role (enum `customer|admin|staff`), preferences (4 arreglos `[String]`), active (`Boolean`), revokedTokens (`[String]`)
- **Product:** sku/name/description/category/image (`String`), type (enum `coffee|dessert|book|service`), price/stock (`Number`), availableFor (`[String]`), formats (`[String]`: `fisico|digital|kindle|local_pc`), rental.enabled/dailyPrice/maxDays, active/featured (`Boolean`)
- **Rental:** user/product (`ObjectId`), startDate/endDate (`Date`), total (`Number`), format (enum `fisico|digital|kindle|local_pc`), paymentStatus (enum `pending|approved|rejected|refunded`), status (enum `pending|active|completed|cancelled`), ticketCode (`String` única)
- **Order:** user (`ObjectId`), items[{product,name,price,quantity,format `fisico|digital`}], total (`Number`), status (enum `pendiente|confirmado|entregado|cancelado`), notes, paymentReference
- **ContactMessage:** name/email/phone/subject/message, audience (enum `duenos|desarrolladores`), status (enum `nuevo|leido`), user (`ObjectId` o null)
- **InventoryMovement:** product/performedBy (`ObjectId`), type (enum `restock|adjustment`), quantity/previousStock/newStock (`Number` enteros), reason (`String`)

## Conexión a Mongo
- Código en `backend/src/config/database.js` (`mongoose.connect(process.env.MONGODB_URI)`), invocado en `server.js` antes de arrancar Express (falla con `exit(1)` si no hay URI)
- **Conectado y probado** contra MongoDB Atlas (2026-11-10): `/api/health`, catálogo, auth, pedidos, alquileres, contacto, IA y rutas admin verificados con `npm test` + `npm run test:admin` (36/36)
- ⚠️ `backend/.env` contiene credenciales reales y está en `.gitignore`; **nunca** pegarlas en `.env.example` ni en el código

## Lecciones de la máquina (Windows/PowerShell)
- `Set-Content` sin `-Encoding` usa ANSI en PS 5.1 y corrompe UTF-8 → usar `-Encoding UTF8`.
- Evitar caracteres unicode literales dentro de comandos; construirlos con `[char]0x0300` / `[char]0x036f` o escapes ASCII en JSON.
- `Start-Process -RedirectStandardOutput` rompe el wrapper de la terminal → arrancar el backend con `Start-Process -FilePath node -ArgumentList "src\server.js" -WindowStyle Hidden` y esperar ~6 s.
