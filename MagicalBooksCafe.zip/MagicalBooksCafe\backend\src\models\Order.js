import mongoose from "mongoose";

const orderItemSchema = new mongoose.Schema(
    {
        product: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Product",
            required: true
        },

        name: {
            type: String,
            required: true
        },

        price: {
            type: Number,
            required: true,
            min: 0
        },

        quantity: {
            type: Number,
            required: true,
            min: 1
        },

        format: {
            type: String,
            enum: ["fisico", "digital"],
            default: null
        }
    },
    { _id: false }
);

const orderSchema = new mongoose.Schema(
    {
        user: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: true
        },

        items: {
            type: [orderItemSchema],
            validate: {
                validator: (items) => items.length > 0,
                message: "El pedido debe tener al menos un producto."
            }
        },

        total: {
            type: Number,
            required: true,
            min: 0
        },

        status: {
            type: String,
            enum: ["pendiente", "confirmado", "entregado", "cancelado"],
            default: "pendiente"
        },

        notes: {
            type: String,
            trim: true,
            maxlength: 500,
            default: ""
        },

        // Referencia de pago cuando el negocio lo confirme manualmente.
        paymentReference: {
            type: String,
            default: null
        }

    },
    { timestamps: true }
);

const Order = mongoose.model("Order", orderSchema);

export default Order;
