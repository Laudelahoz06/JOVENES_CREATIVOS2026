import { useEffect, useState } from "react";

import { apiRequest } from "../services/api";

import AdminProducts from "./admin/AdminProducts";
import AdminOrders from "./admin/AdminOrders";
import AdminRentals from "./admin/AdminRentals";
import AdminMessages from "./admin/AdminMessages";
import AdminUsers from "./admin/AdminUsers";

const TABS = [
    { key: "productos", label: "Productos" },
    { key: "pedidos", label: "Pedidos" },
    { key: "alquileres", label: "Alquileres" },
    { key: "mensajes", label: "Mensajes" },
    { key: "usuarios", label: "Usuarios" }
];

function AdminDashboard() {
    const [accessMessage, setAccessMessage] = useState("");
    const [accessError, setAccessError] = useState("");
    const [activeTab, setActiveTab] = useState("productos");

    useEffect(() => {
        const verifyAccess = async () => {
            try {
                const response = await apiRequest("/admin/access-test");
                setAccessMessage(response.message);
            } catch (err) {
                setAccessError(err.message || "No se pudo verificar el acceso.");
            }
        };

        verifyAccess();
    }, []);

    return (
        <section className="admin-dashboard">
            <div className="admin-welcome">
                <span>✦ MAGICAL BOOKS CAFÉ</span>

                <h1>Panel administrativo</h1>

                <p>
                    {accessMessage ||
                        "Gestiona tu café literario desde un solo lugar."}
                </p>
            </div>

            {accessError && (
                <p className="admin-error">{accessError}</p>
            )}

            <div className="admin-tabs" role="tablist">
                {TABS.map((tab) => (
                    <button
                        key={tab.key}
                        type="button"
                        role="tab"
                        aria-selected={activeTab === tab.key}
                        className={
                            activeTab === tab.key ? "active" : ""
                        }
                        onClick={() => setActiveTab(tab.key)}
                    >
                        {tab.label}
                    </button>
                ))}
            </div>

            <div className="admin-tab-content">
                {activeTab === "productos" && <AdminProducts />}
                {activeTab === "pedidos" && <AdminOrders />}
                {activeTab === "alquileres" && <AdminRentals />}
                {activeTab === "mensajes" && <AdminMessages />}
                {activeTab === "usuarios" && <AdminUsers />}
            </div>
        </section>
    );
}

export default AdminDashboard;
