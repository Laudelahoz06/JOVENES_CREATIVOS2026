import { BrowserRouter, Routes, Route } from "react-router-dom";

import MainLayout from "../layouts/MainLayout";

import Home from "../pages/Home";
import Catalog from "../pages/Catalog";
import ProductDetail from "../pages/ProductDetail";
import Login from "../pages/Login";
import Register from "../pages/Register";
import Contact from "../pages/Contact";
import Cart from "../pages/Cart";
import Profile from "../pages/Profile";
import MyRentals from "../pages/MyRentals";
import NotFound from "../pages/NotFound";

import ProtectedRoute from "../components/common/ProtectedRoute";
import AdminDashboard from "../pages/AdminDashboard";


function AppRouter() {

    return (
        <BrowserRouter>

            <Routes>

                <Route element={<MainLayout />}>

                    <Route path="/" element={<Home />} />

                    <Route path="/catalogo" element={<Catalog />} />

                    <Route
                        path="/catalogo/:id"
                        element={<ProductDetail />}
                    />

                    <Route path="/iniciar-sesion" element={<Login />} />

                    <Route path="/registro" element={<Register />} />

                    <Route path="/contacto" element={<Contact />} />

                    <Route path="/carrito" element={<Cart />} />

                    <Route
                        path="/perfil"
                        element={
                            <ProtectedRoute>
                                <Profile />
                            </ProtectedRoute>
                        }
                    />

                    <Route
                        path="/mis-alquileres"
                        element={
                            <ProtectedRoute>
                                <MyRentals />
                            </ProtectedRoute>
                        }
                    />

                    <Route
                        path="/admin"
                        element={
                            <ProtectedRoute allowedRoles={["admin"]}>
                                <AdminDashboard />
                            </ProtectedRoute>
                        }
                    />

                    <Route path="*" element={<NotFound />} />

                </Route>

            </Routes>

        </BrowserRouter>
    );
}

export default AppRouter;
