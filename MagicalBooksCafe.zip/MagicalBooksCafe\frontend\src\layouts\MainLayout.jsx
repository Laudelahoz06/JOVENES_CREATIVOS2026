import { Outlet } from "react-router-dom";

import Navbar from "../components/Navbar";
import Footer from "../components/common/Footer";
import AssistantWidget from "../components/ai/AssistantWidget";

function MainLayout() {

    return (
        <>
            <Navbar />

            <main>
                <Outlet />
            </main>

            <Footer />

            <AssistantWidget />
        </>
    );
}

export default MainLayout;
